//Software Engineering ACSG-545-01-2022U (Dr. Imad Al Saeed)

//AMC Ticket Manager

//This program will allow the user to select a movie and purchase tickets for it.
//Afterwards, the user will be presented a seating chart to choose where they want to sit.
//Then, they will be shown a receipt of purchase, their seating, and amount of tickets.


package movie.program;

import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.util.Random;
import javax.swing.*;
import javax.swing.event.*;
import java.io.*;



public class main extends javax.swing.JFrame {
    
    //various variables to be shared throughout each screen (ticket screen, seating chart, receipt, etc.) 
    public String movieName = "";
    public String timeSlot = "";
    public Integer total = 0;
    public Integer seatTotal = 0;
    public Integer childTicketTotal = 0;
    public Integer adultTicketTotal = 0;
    public final double adultTicketPrice = 15.00;
    public final double childTicketPrice = 10.00;
    public final double salesTax = 0.1025;
    public boolean movieSelectedBoolean = false;
    public boolean seatSelectedBoolean = false;
    public boolean timeSelectedBoolean = false;
    
    public DecimalFormat df = new DecimalFormat("##0.00");
    
    //parallel arrays for seating chart
    public boolean[] seatBooleanArray = new boolean[24];
    public String[] seatStringArray = {"A1", "A2", "A3", "A4", "A5", "A6",
                                        "B1", "B2", "B3", "B4", "B5", "B6",
                                        "C1", "C2", "C3", "C4", "C5", "C6",
                                        "D1", "D2", "D3", "D4", "D5", "D6"};
    
    //random varible for generating random order number
    Random rand = new Random();
    
    
    
    public main() {
        
        //sets every variable in the seatBooleanArray to flase
        for (int i = 0; i < seatBooleanArray.length; i++){
            seatBooleanArray[i] = false;
        }
        
        initComponents();
    }
    
    

    //THIS IS THE CODE FOR THE PROJECT! Press the plus sign on the left to open the code if it is closed.
    //Code from the "desgin tab" goes here.
    //Code that goes here can ONLY be edited from the DESIGN TAB
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        //This variable list shows all the list of visual and swing components of the program.
        MainPanel = new javax.swing.JPanel();
        //adds a separate screen for purchasing tickets and selecting movies
        TicketMovieScreen = new javax.swing.JPanel();
        //code for the banner_TicketMovieScreen desgin that is displayed on the top of the screen.
        banner_TicketMovieScreen = new javax.swing.JPanel();
        //adds the amc logo image through a jlabel
        AMClogo = new javax.swing.JLabel();
        //this background_full panel is the whole general background of the program, specifically for the ticket/movie screen.
        background_Full = new javax.swing.JPanel();
        //plain label, only purpose is to say "Ticket Count:"
        ticketCountLabel = new javax.swing.JLabel();
        Sonic2_Button = new javax.swing.JButton();
        //button for dr strange mvoie
        drStrangeButton = new javax.swing.JButton();
        //Next set of movie buttons allows to user to select their movie
        //Example: Lightyear button changes variable "movieName" to Lightyear and it is saved.
        Lightyear_Button = new javax.swing.JButton();
        Morbius_Button = new javax.swing.JButton();
        //label that will be changed depending on what movie is selected.
        movieSelectedLabel = new javax.swing.JLabel();
        ToTimeSlotButton = new javax.swing.JButton();
        //Code for the background design of the movie selection area of the screen
        background_movie_area = new javax.swing.JPanel();
        FantasticBeasts_Button = new javax.swing.JButton();
        Batman_Button = new javax.swing.JButton();
        adultLabel = new javax.swing.JLabel();
        childrenLabel = new javax.swing.JLabel();
        totalTicketsLabel = new javax.swing.JLabel();
        AdultPriceLabel = new javax.swing.JLabel();
        AdultTicketNumberLabel = new javax.swing.JLabel();
        //This button, including "childTicketPlus_Button" changes the ticket total variables by adding one whenever clicked
        adultTicketPlus_Button = new javax.swing.JButton();
        //this button, including "childTicketMinus_Button" change the total ticket variables by decreasing by 1 whenever clicked.
        adultTicketMinus_Button = new javax.swing.JButton();
        childPriceLabel = new javax.swing.JLabel();
        ChildTicketNumberLabel = new javax.swing.JLabel();
        childTicketPlus_Button = new javax.swing.JButton();
        childTicketMinus_Button = new javax.swing.JButton();
        pleaseSelectLabel = new javax.swing.JLabel();
        TimeSelectionScreen = new javax.swing.JPanel();
        //code for the banner_TicketMovieScreen desgin that is displayed on the top of the screen.
        banner_time = new javax.swing.JPanel();
        //adds the amc logo image through a jlabel
        AMClogo2 = new javax.swing.JLabel();
        background_time = new javax.swing.JPanel();
        timeSlotPoster = new javax.swing.JLabel();
        backToTicketScreen = new javax.swing.JButton();
        timeslot_background = new javax.swing.JPanel();
        time_930am = new javax.swing.JToggleButton();
        time_1130am = new javax.swing.JToggleButton();
        time_100pm = new javax.swing.JToggleButton();
        time_300pm = new javax.swing.JToggleButton();
        time_400pm = new javax.swing.JToggleButton();
        time_700pm = new javax.swing.JToggleButton();
        ToSeatingChart = new javax.swing.JButton();
        SelectATimeLabel = new javax.swing.JLabel();
        //separate screen for the seating chart
        SeatingChartScreen = new javax.swing.JPanel();
        //code for the banner_TicketMovieScreen desgin that is displayed on the top of the screen.
        banner_SeatingChart = new javax.swing.JPanel();
        //adds the amc logo image through a jlabel
        AMClogo1 = new javax.swing.JLabel();
        backgroundImage = new javax.swing.JPanel();
        ScreenTextLabel = new javax.swing.JLabel();
        ToFinalScreen = new javax.swing.JButton();
        seatD6 = new javax.swing.JToggleButton();
        seatD5 = new javax.swing.JToggleButton();
        seatD4 = new javax.swing.JToggleButton();
        seatD3 = new javax.swing.JToggleButton();
        seatD2 = new javax.swing.JToggleButton();
        seatD1 = new javax.swing.JToggleButton();
        seatC6 = new javax.swing.JToggleButton();
        seatC5 = new javax.swing.JToggleButton();
        seatC4 = new javax.swing.JToggleButton();
        seatC3 = new javax.swing.JToggleButton();
        seatC2 = new javax.swing.JToggleButton();
        seatC1 = new javax.swing.JToggleButton();
        seatB6 = new javax.swing.JToggleButton();
        seatB5 = new javax.swing.JToggleButton();
        seatB4 = new javax.swing.JToggleButton();
        seatB3 = new javax.swing.JToggleButton();
        seatB2 = new javax.swing.JToggleButton();
        seatB1 = new javax.swing.JToggleButton();
        seatA6 = new javax.swing.JToggleButton();
        seatA5 = new javax.swing.JToggleButton();
        seatA4 = new javax.swing.JToggleButton();
        seatA3 = new javax.swing.JToggleButton();
        seatA2 = new javax.swing.JToggleButton();
        seatA1 = new javax.swing.JToggleButton();
        backToTimeSlotScreenButton = new javax.swing.JButton();
        columnALabel = new javax.swing.JLabel();
        columnBLabel = new javax.swing.JLabel();
        columnCLabel = new javax.swing.JLabel();
        columnDLabel = new javax.swing.JLabel();
        row1Label = new javax.swing.JLabel();
        row2Label = new javax.swing.JLabel();
        row3Label = new javax.swing.JLabel();
        row4Label = new javax.swing.JLabel();
        row5Label = new javax.swing.JLabel();
        row6Label = new javax.swing.JLabel();
        ScreenImageLabel = new javax.swing.JLabel();
        totalSeatNumberLabel = new javax.swing.JLabel();
        totalTicketsLabel_seating = new javax.swing.JLabel();
        ReceiptScreen = new javax.swing.JPanel();
        //code for the banner_TicketMovieScreen desgin that is displayed on the top of the screen.
        banner_receipt = new javax.swing.JPanel();
        //adds the amc logo image through a jlabel
        AMClogo3 = new javax.swing.JLabel();
        background_final = new javax.swing.JPanel();
        background_receipt = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        area = new javax.swing.JTextArea();
        moviePoster_receipt = new javax.swing.JLabel();
        posterBorder = new javax.swing.JPanel();
        background_payment = new javax.swing.JPanel();
        textField_digits = new javax.swing.JTextField();
        nameOnCardLabel = new javax.swing.JLabel();
        textField_name = new javax.swing.JTextField();
        textField_credit = new javax.swing.JTextField();
        creditNumLabel = new javax.swing.JLabel();
        expDateLabel = new javax.swing.JLabel();
        ccvLabel = new javax.swing.JLabel();
        ccvInfoLabel = new javax.swing.JLabel();
        receiptToFirstScreenButton = new javax.swing.JButton();
        backToSeatingChartButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner();
        jSpinner2 = new javax.swing.JSpinner();
        expMonthLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AMC Ticket Manager");
        setBackground(new java.awt.Color(255, 51, 0));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setForeground(new java.awt.Color(255, 51, 0));
        setMaximumSize(new java.awt.Dimension(1280, 800));
        setMinimumSize(new java.awt.Dimension(1280, 800));
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        MainPanel.setLayout(new java.awt.CardLayout());

        TicketMovieScreen.setMaximumSize(new java.awt.Dimension(1280, 800));
        TicketMovieScreen.setMinimumSize(new java.awt.Dimension(1280, 800));
        TicketMovieScreen.setPreferredSize(new java.awt.Dimension(1280, 800));
        TicketMovieScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        banner_TicketMovieScreen.setBackground(new java.awt.Color(126, 22, 22));
        banner_TicketMovieScreen.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        banner_TicketMovieScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AMClogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/AMC.png"))); // NOI18N
        //anything that has ".add" is code that adds the visual to the screen.
        banner_TicketMovieScreen.add(AMClogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        TicketMovieScreen.add(banner_TicketMovieScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 150));

        background_Full.setBackground(new java.awt.Color(220, 32, 38));
        background_Full.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        background_Full.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ticketCountLabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ticketCountLabel.setText("Please select ticket amount.");
        background_Full.add(ticketCountLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, -1, -1));

        Sonic2_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Sonic2.jpg"))); // NOI18N
        Sonic2_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Sonic2_Dark.jpg"))); // NOI18N
        background_Full.add(Sonic2_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 30, 200, 300));
        Sonic2_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                movieName = "Sonic The Hedgehog 2";
                pleaseSelectLabel.setText("");
                movieSelectedLabel.setText("Your selected movie is " + movieName);
                movieSelectedBoolean = true;
                timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Sonic2.jpg")));
                moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Sonic2.jpg")));
            }
        });

        //sets image for button
        drStrangeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/DoctorStange.jpg"))); // NOI18N
        drStrangeButton.setMaximumSize(new java.awt.Dimension(200, 300));
        drStrangeButton.setMinimumSize(new java.awt.Dimension(200, 300));
        drStrangeButton.setPreferredSize(new java.awt.Dimension(200, 300));
        drStrangeButton.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/DoctorStange_Dark.jpg"))); // NOI18N
        background_Full.add(drStrangeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 30, -1, -1));
        //This will make the button functional
        drStrangeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                movieName = "Dr. Strange: Multiverse of Madness";
                pleaseSelectLabel.setText("");
                movieSelectedLabel.setText("Your selected movie is " + movieName);
                movieSelectedBoolean = true;
                timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/DoctorStange.jpg")));
                moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/DoctorStange.jpg")));
            }
        });
        //end of button command

        Lightyear_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lightyear.png"))); // NOI18N
        Lightyear_Button.setMaximumSize(new java.awt.Dimension(200, 300));
        Lightyear_Button.setMinimumSize(new java.awt.Dimension(200, 300));
        Lightyear_Button.setPreferredSize(new java.awt.Dimension(200, 300));
        Lightyear_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lightyear_Dark.png"))); // NOI18N
        background_Full.add(Lightyear_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 30, -1, -1));
        Lightyear_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                movieName = "Lightyear";
                pleaseSelectLabel.setText("");
                movieSelectedLabel.setText("Your selected movie is " + movieName);
                movieSelectedBoolean = true;
                timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lightyear.png")));
                moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lightyear.png")));
            }
        });

        Morbius_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Morbius.jpg"))); // NOI18N
        Morbius_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Morbius_Dark.jpg"))); // NOI18N
        background_Full.add(Morbius_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, 200, 290));
        Morbius_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                movieName = "Morbius";
                pleaseSelectLabel.setText("");
                movieSelectedLabel.setText("Your selected movie is " + movieName);
                movieSelectedBoolean = true;
                timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Morbius.jpg")));
                moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Morbius.jpg")));
            }
        });

        movieSelectedLabel.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        background_Full.add(movieSelectedLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 0, -1, 20));

        ToTimeSlotButton.setText("Select a Time Slot");
        //This button takes us to the seating chart
        ToTimeSlotButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToTimeSlotButtonActionPerformed(evt);
            }
        });
        background_Full.add(ToTimeSlotButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 550, -1, -1));

        background_movie_area.setBackground(new java.awt.Color(126, 22, 22));
        background_movie_area.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        background_movie_area.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        FantasticBeasts_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/FantasticBeasts.jpg"))); // NOI18N
        FantasticBeasts_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/FantasticBeasts_Dark.jpg"))); // NOI18N
        background_movie_area.add(FantasticBeasts_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 320, 200, 290));
        FantasticBeasts_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                movieName = "Fantastic Beasts: The Secrets of Dumbledore";
                pleaseSelectLabel.setText("");
                movieSelectedLabel.setText("Your selected movie is " + movieName);
                movieSelectedBoolean = true;
                timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/FantasticBeasts.jpg")));
                moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/FantasticBeasts.jpg")));
            }
        });

        Batman_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TheBatman.jpg"))); // NOI18N
        Batman_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TheBatman_Dark.jpg"))); // NOI18N
        background_movie_area.add(Batman_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 320, 200, 290));
        Batman_Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                movieName = "The Batman";
                pleaseSelectLabel.setText("");
                movieSelectedLabel.setText("Your selected movie is " + movieName);
                movieSelectedBoolean = true;
                timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TheBatman.jpg")));
                moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TheBatman.jpg")));
            }
        });

        background_Full.add(background_movie_area, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 760, 620));

        adultLabel.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        adultLabel.setText("Adult");
        background_Full.add(adultLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, -1, -1));

        childrenLabel.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        childrenLabel.setText("Children ");
        background_Full.add(childrenLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 100, 40));

        totalTicketsLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        totalTicketsLabel.setText("Total Tickets: 0 ");
        background_Full.add(totalTicketsLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, -1, -1));

        AdultPriceLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        AdultPriceLabel.setText("$15.00 each");
        background_Full.add(AdultPriceLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, -1, -1));

        AdultTicketNumberLabel.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        AdultTicketNumberLabel.setText("0");
        background_Full.add(AdultTicketNumberLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 50, 80));

        adultTicketPlus_Button.setBackground(new java.awt.Color(255, 255, 255));
        adultTicketPlus_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Plus.png"))); // NOI18N
        adultTicketPlus_Button.setBorderPainted(false);
        adultTicketPlus_Button.setContentAreaFilled(false);
        adultTicketPlus_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Plus_Pressed.png"))); // NOI18N
        adultTicketPlus_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adultTicketPlus_ButtonActionPerformed(evt);
            }
        });
        background_Full.add(adultTicketPlus_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, -1, -1));

        adultTicketMinus_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Minus.png"))); // NOI18N
        adultTicketMinus_Button.setBorderPainted(false);
        adultTicketMinus_Button.setContentAreaFilled(false);
        adultTicketMinus_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Minus_Pressed.png"))); // NOI18N
        adultTicketMinus_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adultTicketMinus_ButtonActionPerformed(evt);
            }
        });
        background_Full.add(adultTicketMinus_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 120, -1));

        childPriceLabel.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        childPriceLabel.setText("$10.00 each");
        background_Full.add(childPriceLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(185, 350, -1, -1));

        ChildTicketNumberLabel.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        ChildTicketNumberLabel.setText("0");
        background_Full.add(ChildTicketNumberLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 380, 60, -1));

        childTicketPlus_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Plus.png"))); // NOI18N
        childTicketPlus_Button.setBorderPainted(false);
        childTicketPlus_Button.setContentAreaFilled(false);
        childTicketPlus_Button.setFocusPainted(false);
        childTicketPlus_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Plus_Pressed.png"))); // NOI18N
        childTicketPlus_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                childTicketPlus_ButtonActionPerformed(evt);
            }
        });
        background_Full.add(childTicketPlus_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 360, 150, -1));

        childTicketMinus_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Minus.png"))); // NOI18N
        childTicketMinus_Button.setContentAreaFilled(false);
        childTicketMinus_Button.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Minus_Pressed.png"))); // NOI18N
        childTicketMinus_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                childTicketMinus_ButtonActionPerformed(evt);
            }
        });
        background_Full.add(childTicketMinus_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 120, -1));

        pleaseSelectLabel.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        pleaseSelectLabel.setText("Please select a movie.");
        background_Full.add(pleaseSelectLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, -4, -1, 30));

        TicketMovieScreen.add(background_Full, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 1280, 650));

        MainPanel.add(TicketMovieScreen, "TicketMovieScreen");

        TimeSelectionScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        banner_time.setBackground(new java.awt.Color(126, 22, 22));
        banner_time.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        banner_time.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AMClogo2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/AMC.png"))); // NOI18N
        //anything that has ".add" is code that adds the visual to the screen.
        banner_time.add(AMClogo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        TimeSelectionScreen.add(banner_time, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 150));

        background_time.setBackground(new java.awt.Color(220, 32, 38));
        background_time.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        background_time.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        timeSlotPoster.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Lightyear.png"))); // NOI18N
        background_time.add(timeSlotPoster, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 200, 300));

        backToTicketScreen.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        backToTicketScreen.setText("Go Back");
        backToTicketScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToTicketScreenActionPerformed(evt);
            }
        });
        background_time.add(backToTicketScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 680, -1, -1));

        timeslot_background.setBackground(new java.awt.Color(126, 22, 22));
        timeslot_background.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        timeslot_background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        time_930am.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/930am.png"))); // NOI18N
        time_930am.setContentAreaFilled(false);
        time_930am.setRolloverEnabled(false);
        time_930am.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/930am_selected.png"))); // NOI18N
        time_930am.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_930amActionPerformed(evt);
            }
        });
        timeslot_background.add(time_930am, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 30, 160, 80));

        time_1130am.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/1130am.png"))); // NOI18N
        time_1130am.setContentAreaFilled(false);
        time_1130am.setRolloverEnabled(false);
        time_1130am.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/1130_selected.png"))); // NOI18N
        time_1130am.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_1130amActionPerformed(evt);
            }
        });
        timeslot_background.add(time_1130am, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 30, 160, 80));

        time_100pm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/100pm.png"))); // NOI18N
        time_100pm.setContentAreaFilled(false);
        time_100pm.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/100pm_selected.png"))); // NOI18N
        time_100pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_100pmActionPerformed(evt);
            }
        });
        timeslot_background.add(time_100pm, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 30, 160, 80));

        time_300pm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/300pm.png"))); // NOI18N
        time_300pm.setContentAreaFilled(false);
        time_300pm.setRolloverEnabled(false);
        time_300pm.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/300pm_selected.png"))); // NOI18N
        time_300pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_300pmActionPerformed(evt);
            }
        });
        timeslot_background.add(time_300pm, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 200, 160, 80));

        time_400pm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/400pm.png"))); // NOI18N
        time_400pm.setContentAreaFilled(false);
        time_400pm.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/400pm_selected.png"))); // NOI18N
        time_400pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_400pmActionPerformed(evt);
            }
        });
        timeslot_background.add(time_400pm, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 200, 160, 80));

        time_700pm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/700pm.png"))); // NOI18N
        time_700pm.setContentAreaFilled(false);
        time_700pm.setRolloverEnabled(false);
        time_700pm.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/TimeSlots/700pm_selected.png"))); // NOI18N
        time_700pm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                time_700pmActionPerformed(evt);
            }
        });
        timeslot_background.add(time_700pm, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 200, 160, 80));

        background_time.add(timeslot_background, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 270, 1010, 320));

        ToSeatingChart.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ToSeatingChart.setText("Confirm Selection");
        ToSeatingChart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToSeatingChartActionPerformed(evt);
            }
        });
        background_time.add(ToSeatingChart, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 680, -1, -1));

        SelectATimeLabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        SelectATimeLabel.setText("Please select a time slot.");
        background_time.add(SelectATimeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 240, -1, -1));

        TimeSelectionScreen.add(background_time, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 800));

        MainPanel.add(TimeSelectionScreen, "card5");

        SeatingChartScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        banner_SeatingChart.setBackground(new java.awt.Color(126, 22, 22));
        banner_SeatingChart.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        banner_SeatingChart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AMClogo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/AMC.png"))); // NOI18N
        //anything that has ".add" is code that adds the visual to the screen.
        banner_SeatingChart.add(AMClogo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        SeatingChartScreen.add(banner_SeatingChart, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 150));

        backgroundImage.setBackground(new java.awt.Color(220, 32, 38));
        backgroundImage.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        backgroundImage.setMinimumSize(new java.awt.Dimension(1260, 640));
        backgroundImage.setPreferredSize(new java.awt.Dimension(1260, 640));
        backgroundImage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ScreenTextLabel.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        ScreenTextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ScreenTextLabel.setText("Screen");
        backgroundImage.add(ScreenTextLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, -10, 90, 70));

        ToFinalScreen.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ToFinalScreen.setText("Proceed to Payment");
        ToFinalScreen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToFinalScreenActionPerformed(evt);
            }
        });
        backgroundImage.add(ToFinalScreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 580, -1, -1));

        seatD6.setBackground(new java.awt.Color(255, 255, 255));
        seatD6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD6.setContentAreaFilled(false);
        seatD6.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD6.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatD6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatD6ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatD6, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 480, -1, -1));

        seatD5.setBackground(new java.awt.Color(255, 255, 255));
        seatD5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD5.setContentAreaFilled(false);
        seatD5.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD5.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatD5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatD5ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatD5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 480, -1, -1));

        seatD4.setBackground(new java.awt.Color(255, 255, 255));
        seatD4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD4.setContentAreaFilled(false);
        seatD4.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD4.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatD4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatD4ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatD4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 480, -1, -1));

        seatD3.setBackground(new java.awt.Color(255, 255, 255));
        seatD3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD3.setContentAreaFilled(false);
        seatD3.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatD3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatD3ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatD3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 480, -1, -1));

        seatD2.setBackground(new java.awt.Color(255, 255, 255));
        seatD2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD2.setContentAreaFilled(false);
        seatD2.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatD2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatD2ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatD2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, -1, -1));

        seatD1.setBackground(new java.awt.Color(255, 255, 255));
        seatD1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD1.setContentAreaFilled(false);
        seatD1.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatD1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatD1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatD1ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatD1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 480, -1, -1));

        seatC6.setBackground(new java.awt.Color(255, 255, 255));
        seatC6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC6.setContentAreaFilled(false);
        seatC6.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC6.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatC6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatC6ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatC6, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 360, -1, -1));

        seatC5.setBackground(new java.awt.Color(255, 255, 255));
        seatC5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC5.setContentAreaFilled(false);
        seatC5.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC5.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatC5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatC5ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatC5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 360, -1, -1));

        seatC4.setBackground(new java.awt.Color(255, 255, 255));
        seatC4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC4.setContentAreaFilled(false);
        seatC4.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC4.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatC4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatC4ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatC4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 360, -1, -1));

        seatC3.setBackground(new java.awt.Color(255, 255, 255));
        seatC3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC3.setContentAreaFilled(false);
        seatC3.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatC3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatC3ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatC3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 360, -1, -1));

        seatC2.setBackground(new java.awt.Color(255, 255, 255));
        seatC2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC2.setContentAreaFilled(false);
        seatC2.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatC2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatC2ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatC2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 360, -1, -1));

        seatC1.setBackground(new java.awt.Color(255, 255, 255));
        seatC1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC1.setContentAreaFilled(false);
        seatC1.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatC1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatC1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatC1ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatC1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 360, -1, -1));

        seatB6.setBackground(new java.awt.Color(255, 255, 255));
        seatB6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB6.setContentAreaFilled(false);
        seatB6.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB6.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatB6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatB6ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatB6, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 240, -1, -1));

        seatB5.setBackground(new java.awt.Color(255, 255, 255));
        seatB5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB5.setContentAreaFilled(false);
        seatB5.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB5.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatB5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatB5ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatB5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 240, -1, -1));

        seatB4.setBackground(new java.awt.Color(255, 255, 255));
        seatB4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB4.setContentAreaFilled(false);
        seatB4.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB4.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatB4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatB4ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatB4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 240, -1, -1));

        seatB3.setBackground(new java.awt.Color(255, 255, 255));
        seatB3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB3.setContentAreaFilled(false);
        seatB3.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatB3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatB3ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatB3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 240, -1, -1));

        seatB2.setBackground(new java.awt.Color(255, 255, 255));
        seatB2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB2.setContentAreaFilled(false);
        seatB2.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatB2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatB2ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatB2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 240, -1, -1));

        seatB1.setBackground(new java.awt.Color(255, 255, 255));
        seatB1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB1.setContentAreaFilled(false);
        seatB1.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatB1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatB1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatB1ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatB1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 240, -1, -1));

        seatA6.setBackground(new java.awt.Color(255, 255, 255));
        seatA6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA6.setContentAreaFilled(false);
        seatA6.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA6.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatA6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatA6ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatA6, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 120, -1, -1));

        seatA5.setBackground(new java.awt.Color(255, 255, 255));
        seatA5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA5.setContentAreaFilled(false);
        seatA5.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA5.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatA5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatA5ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatA5, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 120, -1, -1));

        seatA4.setBackground(new java.awt.Color(255, 255, 255));
        seatA4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA4.setContentAreaFilled(false);
        seatA4.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA4.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatA4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatA4ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatA4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 120, -1, -1));

        seatA3.setBackground(new java.awt.Color(255, 255, 255));
        seatA3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA3.setContentAreaFilled(false);
        seatA3.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatA3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatA3ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatA3, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 120, -1, -1));

        seatA2.setBackground(new java.awt.Color(255, 255, 255));
        seatA2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA2.setContentAreaFilled(false);
        seatA2.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatA2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatA2ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatA2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 120, -1, -1));

        seatA1.setBackground(new java.awt.Color(255, 255, 255));
        seatA1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA1.setContentAreaFilled(false);
        seatA1.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_unselected.png"))); // NOI18N
        seatA1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/chair_selected.png"))); // NOI18N
        seatA1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatA1ActionPerformed(evt);
            }
        });
        backgroundImage.add(seatA1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, -1, -1));

        backToTimeSlotScreenButton.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        backToTimeSlotScreenButton.setText("Go Back");
        backToTimeSlotScreenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToTimeSlotScreenButtonActionPerformed(evt);
            }
        });
        backgroundImage.add(backToTimeSlotScreenButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 580, -1, -1));

        columnALabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        columnALabel.setText("A");
        backgroundImage.add(columnALabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, -1, 30));

        columnBLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        columnBLabel.setText("B");
        backgroundImage.add(columnBLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, -1, -1));

        columnCLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        columnCLabel.setText("C");
        backgroundImage.add(columnCLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 410, -1, -1));

        columnDLabel.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        columnDLabel.setText("D");
        backgroundImage.add(columnDLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 530, -1, -1));

        row1Label.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        row1Label.setText("1");
        backgroundImage.add(row1Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, -1, -1));

        row2Label.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        row2Label.setText("2");
        backgroundImage.add(row2Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 90, -1, -1));

        row3Label.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        row3Label.setText("3");
        backgroundImage.add(row3Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, -1, -1));

        row4Label.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        row4Label.setText("4");
        backgroundImage.add(row4Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 90, -1, -1));

        row5Label.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        row5Label.setText("5");
        backgroundImage.add(row5Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 90, -1, -1));

        row6Label.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        row6Label.setText("6");
        backgroundImage.add(row6Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 90, -1, -1));

        ScreenImageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ScreenImageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/screen.png"))); // NOI18N
        backgroundImage.add(ScreenImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 800, 170));

        totalSeatNumberLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        totalSeatNumberLabel.setText("Seats Selected: 0");
        backgroundImage.add(totalSeatNumberLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 160, -1, -1));

        totalTicketsLabel_seating.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        totalTicketsLabel_seating.setText("Total Tickets: 0 ");
        backgroundImage.add(totalTicketsLabel_seating, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 190, -1, -1));

        SeatingChartScreen.add(backgroundImage, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 1280, 650));

        MainPanel.add(SeatingChartScreen, "SeatingChartScreen");

        ReceiptScreen.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        banner_receipt.setBackground(new java.awt.Color(126, 22, 22));
        banner_receipt.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        banner_receipt.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AMClogo3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/AMC.png"))); // NOI18N
        //anything that has ".add" is code that adds the visual to the screen.
        banner_receipt.add(AMClogo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, -1));

        ReceiptScreen.add(banner_receipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 150));

        background_final.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        background_receipt.setBackground(new java.awt.Color(220, 32, 38));
        background_receipt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        background_receipt.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(89, 22, 22));
        jScrollPane1.setBorder(null);
        jScrollPane1.setForeground(new java.awt.Color(89, 22, 22));

        area.setEditable(false);
        area.setBackground(new java.awt.Color(126, 22, 22));
        area.setColumns(20);
        area.setFont(new java.awt.Font("Monospaced", 1, 16)); // NOI18N
        area.setForeground(new java.awt.Color(255, 255, 255));
        area.setLineWrap(true);
        area.setRows(5);
        area.setWrapStyleWord(true);
        area.setAutoscrolls(false);
        area.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        area.setFocusable(false);
        jScrollPane1.setViewportView(area);

        background_receipt.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 190, 420, 480));

        moviePoster_receipt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/FantasticBeasts.jpg"))); // NOI18N
        background_receipt.add(moviePoster_receipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, -1, 300));

        posterBorder.setBackground(new java.awt.Color(89, 22, 22));
        posterBorder.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        posterBorder.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        background_receipt.add(posterBorder, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 220, 320));

        background_payment.setBackground(new java.awt.Color(126, 22, 22));
        background_payment.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(89, 22, 22)));
        background_payment.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        textField_digits.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        background_payment.add(textField_digits, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 290, 70, -1));

        nameOnCardLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        nameOnCardLabel.setText("Name on Card:");
        background_payment.add(nameOnCardLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 70, -1, 20));

        textField_name.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        background_payment.add(textField_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 90, 220, -1));

        textField_credit.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        background_payment.add(textField_credit, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 150, 190, -1));

        creditNumLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        creditNumLabel.setText("Credit Card Number:");
        background_payment.add(creditNumLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, -1, -1));

        expDateLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        expDateLabel.setText("Exp. Date:");
        background_payment.add(expDateLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, -1, -1));

        ccvLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ccvLabel.setText("CCV Code:");
        background_payment.add(ccvLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 270, -1, -1));

        ccvInfoLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        ccvInfoLabel.setForeground(new java.awt.Color(255, 255, 255));
        ccvInfoLabel.setText("?");
        ccvInfoLabel.setToolTipText("Three digits on the back of your credit card.");
        background_payment.add(ccvInfoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 290, 20, 30));

        receiptToFirstScreenButton.setText("Go to Start");
        receiptToFirstScreenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                receiptToFirstScreenButtonActionPerformed(evt);
            }
        });
        background_payment.add(receiptToFirstScreenButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, 90, -1));

        backToSeatingChartButton.setText("Pick Seats");
        backToSeatingChartButton.setPreferredSize(new java.awt.Dimension(85, 23));
        backToSeatingChartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backToSeatingChartButtonActionPerformed(evt);
            }
        });
        background_payment.add(backToSeatingChartButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 430, 90, -1));

        printButton.setText("Confirm Purchase");
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        background_payment.add(printButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 350, -1, -1));

        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(1, 1, 12, 1));
        background_payment.add(jSpinner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 230, 50, 30));

        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(23, 23, null, 1));
        background_payment.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 230, 50, 30));

        expMonthLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        expMonthLabel.setText("Month");
        background_payment.add(expMonthLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 210, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Year");
        background_payment.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 210, -1, -1));

        background_receipt.add(background_payment, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 750, 480));

        background_final.add(background_receipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 800));

        ReceiptScreen.add(background_final, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 800));

        MainPanel.add(ReceiptScreen, "card4");

        getContentPane().add(MainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 800));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    //This give functionality to the seating chart button
    //This button allows the user to go to the seating chart after they have selected tickets and movies
    //This buttons gives the user an error if they didnt select a movie or if they have a ticket count of less than 1
    private void ToTimeSlotButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToTimeSlotButtonActionPerformed
        CardLayout card = (CardLayout)MainPanel.getLayout();
        if (movieSelectedBoolean == false || total < 1) {
                    JOptionPane.showMessageDialog(this, "Please select a movie and at least one ticket!");
                } else if (adultTicketTotal == 0 && childTicketTotal > 0) {
                    JOptionPane.showMessageDialog(this, "You must be accompanied by at least one adult!");
                } else {
                    card.next(MainPanel);
                }
    }//GEN-LAST:event_ToTimeSlotButtonActionPerformed

    //These next two button actions are for selecting tickets.
    //Pressing the plus button increases the ticket total for adults by 1.
    //Pressing the minus button decreases the ticket total for adults by 1.
    //These button actions are for the MOVIE/TICKET SCREEN
    private void adultTicketPlus_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adultTicketPlus_ButtonActionPerformed
            adultTicketTotal = adultTicketTotal + 1;
            if (adultTicketTotal > 9){
                adultTicketTotal = 9;
                AdultTicketNumberLabel.setText("9");
            } else {  
            AdultTicketNumberLabel.setText("" + adultTicketTotal);
            }
            total = (adultTicketTotal + childTicketTotal);
            totalTicketsLabel.setText("Total Tickets: " + total);
            totalTicketsLabel_seating.setText("Total Tickets: " + total);
    }//GEN-LAST:event_adultTicketPlus_ButtonActionPerformed

    private void adultTicketMinus_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adultTicketMinus_ButtonActionPerformed
            adultTicketTotal = adultTicketTotal - 1;
            if (adultTicketTotal < 0){
                adultTicketTotal = 0;
                AdultTicketNumberLabel.setText("0");
            } else {  
            AdultTicketNumberLabel.setText("" + adultTicketTotal);
            }
            total = (adultTicketTotal + childTicketTotal);
            totalTicketsLabel.setText("Total Tickets: " + total);
            totalTicketsLabel_seating.setText("Total Tickets: " + total);
    }//GEN-LAST:event_adultTicketMinus_ButtonActionPerformed

    private void childTicketPlus_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_childTicketPlus_ButtonActionPerformed
            childTicketTotal = childTicketTotal + 1;
            if (childTicketTotal > 9){
                childTicketTotal = 9;
                ChildTicketNumberLabel.setText("9");
            } else {  
            ChildTicketNumberLabel.setText("" + childTicketTotal);
            }
            total = (adultTicketTotal + childTicketTotal);
            totalTicketsLabel.setText("Total Tickets: " + total);
            totalTicketsLabel_seating.setText("Total Tickets: " + total);
    }//GEN-LAST:event_childTicketPlus_ButtonActionPerformed

    private void childTicketMinus_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_childTicketMinus_ButtonActionPerformed
            childTicketTotal = childTicketTotal - 1;
            if (childTicketTotal < 0){
                childTicketTotal = 0;
                ChildTicketNumberLabel.setText("0");
            } else {  
            ChildTicketNumberLabel.setText("" + childTicketTotal);
            }
            total = (adultTicketTotal + childTicketTotal);
            totalTicketsLabel.setText("Total Tickets: " + total);
            totalTicketsLabel_seating.setText("Total Tickets: " + total);
    }//GEN-LAST:event_childTicketMinus_ButtonActionPerformed

    //These next 24 Action Performed methods are the individual coding for each seat button.
    //Each action adds a number to seatTotal to track how many seats are selected. It also makes the the SeatBooleanArray for that seat true.
    //If unselected, this makes the seat selected false, and subtracts from the seatTotal.
    private void seatA1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatA1ActionPerformed
        if (seatA1.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[0] = true;
        }
        if (seatA1.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[0] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatA1ActionPerformed

    private void seatA2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatA2ActionPerformed
        if (seatA2.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[1] = true;
        }
        if (seatA2.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[1] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatA2ActionPerformed

    private void seatA3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatA3ActionPerformed
        if (seatA3.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[2] = true;
        }
        if (seatA3.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[2] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatA3ActionPerformed

    private void seatA4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatA4ActionPerformed
        if (seatA4.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[3] = true;
        }
        if (seatA4.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[3] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatA4ActionPerformed

    private void seatA5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatA5ActionPerformed
        if (seatA5.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[4] = true;
        }
        if (seatA5.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[4] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatA5ActionPerformed

    private void seatA6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatA6ActionPerformed
        if (seatA6.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[5] = true;
        }
        if (seatA6.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[5] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatA6ActionPerformed

    private void seatB1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatB1ActionPerformed
        if (seatB1.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[6] = true;
        }
        if (seatB1.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[6] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatB1ActionPerformed

    private void seatB2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatB2ActionPerformed
        if (seatB2.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[7] = true;
        }
        if (seatB2.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[7] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatB2ActionPerformed

    private void seatB3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatB3ActionPerformed
        if (seatB3.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[8] = true;
        }
        if (seatB3.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[8] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatB3ActionPerformed

    private void seatB4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatB4ActionPerformed
        if (seatB4.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[9] = true;
        }
        if (seatB4.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[9] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatB4ActionPerformed

    private void seatB5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatB5ActionPerformed
        if (seatB5.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[10] = true;
        }
        if (seatB5.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[10] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatB5ActionPerformed

    private void seatB6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatB6ActionPerformed
        if (seatB6.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[11] = true;
        }
        if (seatB6.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[11] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatB6ActionPerformed

    private void seatC1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatC1ActionPerformed
        if (seatC1.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[12] = true;
        }
        if (seatC1.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[12] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatC1ActionPerformed

    private void seatC2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatC2ActionPerformed
        if (seatC2.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[13] = true;
        }
        if (seatC2.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[13] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatC2ActionPerformed

    private void seatC3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatC3ActionPerformed
        if (seatC3.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[14] = true;
        }
        if (seatC3.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[14] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatC3ActionPerformed

    private void seatC4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatC4ActionPerformed
        if (seatC4.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[15] = true;
        }
        if (seatC4.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[15] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatC4ActionPerformed

    private void seatC5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatC5ActionPerformed
        if (seatC5.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[16] = true;
        }
        if (seatC5.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[16] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatC5ActionPerformed

    private void seatC6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatC6ActionPerformed
        if (seatC6.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[17] = true;
        }
        if (seatC6.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[17] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatC6ActionPerformed

    private void seatD1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatD1ActionPerformed
        if (seatD1.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[18] = true;
        }
        if (seatD1.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[18] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatD1ActionPerformed

    private void seatD2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatD2ActionPerformed
        if (seatD2.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[19] = true;
        }
        if (seatD2.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[19] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatD2ActionPerformed

    private void seatD3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatD3ActionPerformed
        if (seatD3.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[20] = true;
        }
        if (seatD3.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[20] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatD3ActionPerformed

    private void seatD4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatD4ActionPerformed
        if (seatD4.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[21] = true;
        }
        if (seatD4.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[21] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatD4ActionPerformed

    private void seatD5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatD5ActionPerformed
        if (seatD5.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[22] = true;
        }
        if (seatD5.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[22] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatD5ActionPerformed

    private void seatD6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatD6ActionPerformed
        if (seatD6.isSelected()){
            seatTotal = seatTotal + 1;
            seatBooleanArray[23] = true;
        }
        if (seatD6.isSelected() == false){
            seatTotal = seatTotal - 1;
            seatBooleanArray[23] = false;
        }
        totalSeatNumberLabel.setText("Seats Selected: " + seatTotal);
    }//GEN-LAST:event_seatD6ActionPerformed

    //This button takes the user to the purchase/receipt screen.
    //This button also generates the entire receipt with previous data selected by the user.
    //Here they will be presented with their selected seats, total tickets, time slots, and total cost.
    //The user will also be prompted to enter their credit card information.
    private void ToFinalScreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToFinalScreenActionPerformed
        Double childTotalPrice = childTicketTotal * childTicketPrice;
        Double adultTotalPrice = adultTicketTotal * adultTicketPrice;
        Double totalPrice = adultTotalPrice + childTotalPrice;
        Double tax = (childTotalPrice + adultTotalPrice) * salesTax;
        Double grandTotal = (childTotalPrice + adultTotalPrice) + tax;
        if (seatTotal != total) {
            JOptionPane.showMessageDialog(this, "Your seat selection is not equal to your ticket count!");
        } else {
        area.setText("        AMC Receipt Order #" + (rand.nextInt(9999) + 1000) + "\n");
        area.setText(area.getText() + "----------------------------------------\n");
        area.setText(area.getText() + " " + movieName + "\n");
        area.setText(area.getText() + " " + timeSlot + "\n");
        area.setText(area.getText() + " " + "\n Your seats are: \n");
        for (int k = 0; k < seatBooleanArray.length; k++){
        if (seatBooleanArray[k] == true){
            if (k == 5 || k == 11) {
            area.setText(area.getText() + " " + seatStringArray[k] + "\n");
            } else {
            area.setText(area.getText() + " " + seatStringArray[k] + " ");    
            }
          }
        }
                area.setText(area.getText() + "\n\n");
        area.setText(area.getText() + " " + adultTicketTotal + "x Adult Ticket(s) - "  + df.format(adultTotalPrice) + "\n");
        area.setText(area.getText() + " " + childTicketTotal + "x Child Ticket(s) - " + df.format(childTotalPrice) + "\n");
        area.setText(area.getText() + " " + total + " Total Tickets" + "\n\n\n");
        area.setText(area.getText() + "----------------------------------------\n");
        area.setText(area.getText() + " Subtotal = $" + df.format(totalPrice) + "\n");
        area.setText(area.getText() + " Tax      = $" + df.format(tax) + "\n");
        area.setText(area.getText() + " Total    = $" + df.format(grandTotal) + "\n");
        CardLayout card = (CardLayout)MainPanel.getLayout();
        card.next(MainPanel);
        }
    }//GEN-LAST:event_ToFinalScreenActionPerformed

    private void backToTicketScreenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToTicketScreenActionPerformed
        CardLayout card = (CardLayout)MainPanel.getLayout();
        card.previous(MainPanel);
    }//GEN-LAST:event_backToTicketScreenActionPerformed

    private void ToSeatingChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToSeatingChartActionPerformed
        if (timeSelectedBoolean == false){
           JOptionPane.showMessageDialog(this, "Please select a time slot!"); 
        } else {
        CardLayout card = (CardLayout)MainPanel.getLayout();
        card.next(MainPanel);
        }
    }//GEN-LAST:event_ToSeatingChartActionPerformed

    //the next 6 buttons are for functionality of the time slot toggle buttons.
    //If one time slot toggle is pressed, it will unselect the other time slot toggles if they are selected.
    private void time_930amActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_930amActionPerformed
        if (time_930am.isSelected()){
            timeSlot = "9:30am";
            timeSelectedBoolean = true; 
        }
        if (time_930am.isSelected() == false){
            timeSelectedBoolean = false;
        }
        if (time_1130am.isSelected() || time_100pm.isSelected() || time_300pm.isSelected() || time_400pm.isSelected() || time_700pm.isSelected()){
            time_1130am.setSelected(false);
            time_100pm.setSelected(false);
            time_300pm.setSelected(false);
            time_400pm.setSelected(false);
            time_700pm.setSelected(false);
        }
    }//GEN-LAST:event_time_930amActionPerformed

    private void time_1130amActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_1130amActionPerformed
        if (time_1130am.isSelected()){
            timeSlot = "11:30am";
            timeSelectedBoolean = true; 
        }
        if (time_1130am.isSelected() == false){
            timeSelectedBoolean = false;
        }
        if (time_930am.isSelected() || time_100pm.isSelected() || time_300pm.isSelected() || time_400pm.isSelected() || time_700pm.isSelected()){
            time_930am.setSelected(false);
            time_100pm.setSelected(false);
            time_300pm.setSelected(false);
            time_400pm.setSelected(false);
            time_700pm.setSelected(false);
        }
    }//GEN-LAST:event_time_1130amActionPerformed

    private void time_100pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_100pmActionPerformed
            if (time_100pm.isSelected()){
            timeSlot = "1:00pm";
            timeSelectedBoolean = true; 
        }
        if (time_100pm.isSelected() == false){
            timeSelectedBoolean = false;
        }
        if (time_930am.isSelected() || time_1130am.isSelected() || time_300pm.isSelected() || time_400pm.isSelected() || time_700pm.isSelected()){
            time_1130am.setSelected(false);
            time_930am.setSelected(false);
            time_300pm.setSelected(false);
            time_400pm.setSelected(false);
            time_700pm.setSelected(false);
        }
    }//GEN-LAST:event_time_100pmActionPerformed

    private void time_300pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_300pmActionPerformed
        if (time_300pm.isSelected()){
        timeSlot = "3:00pm";
        timeSelectedBoolean = true; 
        }
        if (time_300pm.isSelected() == false){
            timeSelectedBoolean = false;
        }
        if (time_930am.isSelected() || time_1130am.isSelected() || time_100pm.isSelected() || time_400pm.isSelected() || time_700pm.isSelected()){
            time_1130am.setSelected(false);
            time_930am.setSelected(false);
            time_100pm.setSelected(false);
            time_400pm.setSelected(false);
            time_700pm.setSelected(false);
        }
    }//GEN-LAST:event_time_300pmActionPerformed

    private void time_400pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_400pmActionPerformed
        if (time_400pm.isSelected()){
        timeSlot = "4:00pm";
        timeSelectedBoolean = true; 
        }
        if (time_400pm.isSelected() == false){
            timeSelectedBoolean = false;
        }
        if (time_930am.isSelected() || time_1130am.isSelected() || time_100pm.isSelected() || time_400pm.isSelected() || time_700pm.isSelected()){
            time_1130am.setSelected(false);
            time_930am.setSelected(false);
            time_300pm.setSelected(false);
            time_100pm.setSelected(false);
            time_700pm.setSelected(false);
        }
    }//GEN-LAST:event_time_400pmActionPerformed

    private void time_700pmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_time_700pmActionPerformed
        if (time_700pm.isSelected()){
        timeSlot = "7:00pm";
        timeSelectedBoolean = true; 
        }
        if (time_700pm.isSelected() == false){
            timeSelectedBoolean = false;
        }
        if (time_930am.isSelected() || time_1130am.isSelected() || time_100pm.isSelected() || time_400pm.isSelected() || time_400pm.isSelected()){
            time_1130am.setSelected(false);
            time_930am.setSelected(false);
            time_300pm.setSelected(false);
            time_100pm.setSelected(false);
            time_400pm.setSelected(false);
        }
    }//GEN-LAST:event_time_700pmActionPerformed

    private void backToTimeSlotScreenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToTimeSlotScreenButtonActionPerformed
        CardLayout card = (CardLayout)MainPanel.getLayout();
        card.previous(MainPanel);
    }//GEN-LAST:event_backToTimeSlotScreenButtonActionPerformed

    private void receiptToFirstScreenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_receiptToFirstScreenButtonActionPerformed
        CardLayout card = (CardLayout)MainPanel.getLayout();
        card.first(MainPanel);
    }//GEN-LAST:event_receiptToFirstScreenButtonActionPerformed

    private void backToSeatingChartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backToSeatingChartButtonActionPerformed
        CardLayout card = (CardLayout)MainPanel.getLayout();
        card.previous(MainPanel);
    }//GEN-LAST:event_backToSeatingChartButtonActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
            if (textField_credit.getText().length() != 16 || textField_digits.getText().length() != 3){
            JOptionPane.showMessageDialog(this, "Invalid Payment Info\nCheck your:\n-Credit card number (16 digits)\n-Expiration date\n-Security code (3 digits on the back of your card)");                
            } else {
                int result = JOptionPane.showConfirmDialog(this, "Thank you for choosing AMC!\nWould you like to print a receipt?", "Thank You!", JOptionPane.YES_NO_OPTION);
                switch (result){
                    case JOptionPane.YES_OPTION:
                    area.setForeground(new java.awt.Color(0, 0, 0));
                    try {
                        area.print();
                        }
                    catch(Exception e)
                    {
                    }
                    area.setForeground(new java.awt.Color(255, 255, 255));
                    break;
                    case JOptionPane.NO_OPTION:
                    break;
                }
            }
    }//GEN-LAST:event_printButtonActionPerformed

    

    //THIS IS THE END OF THE CODE FOR THE PROJECT

    
    
    
    
    
    
    
    
    
    
    
    
    

    
    //DO NOT EDIT
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AMClogo;
    private javax.swing.JLabel AMClogo1;
    private javax.swing.JLabel AMClogo2;
    private javax.swing.JLabel AMClogo3;
    private javax.swing.JLabel AdultPriceLabel;
    private javax.swing.JLabel AdultTicketNumberLabel;
    private javax.swing.JButton Batman_Button;
    private javax.swing.JLabel ChildTicketNumberLabel;
    private javax.swing.JButton FantasticBeasts_Button;
    private javax.swing.JButton Lightyear_Button;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JButton Morbius_Button;
    private javax.swing.JPanel ReceiptScreen;
    private javax.swing.JLabel ScreenImageLabel;
    private javax.swing.JLabel ScreenTextLabel;
    private javax.swing.JPanel SeatingChartScreen;
    private javax.swing.JLabel SelectATimeLabel;
    private javax.swing.JButton Sonic2_Button;
    private javax.swing.JPanel TicketMovieScreen;
    private javax.swing.JPanel TimeSelectionScreen;
    private javax.swing.JButton ToFinalScreen;
    private javax.swing.JButton ToSeatingChart;
    private javax.swing.JButton ToTimeSlotButton;
    private javax.swing.JLabel adultLabel;
    private javax.swing.JButton adultTicketMinus_Button;
    private javax.swing.JButton adultTicketPlus_Button;
    private javax.swing.JTextArea area;
    private javax.swing.JButton backToSeatingChartButton;
    private javax.swing.JButton backToTicketScreen;
    private javax.swing.JButton backToTimeSlotScreenButton;
    private javax.swing.JPanel backgroundImage;
    private javax.swing.JPanel background_Full;
    private javax.swing.JPanel background_final;
    private javax.swing.JPanel background_movie_area;
    private javax.swing.JPanel background_payment;
    private javax.swing.JPanel background_receipt;
    private javax.swing.JPanel background_time;
    private javax.swing.JPanel banner_SeatingChart;
    private javax.swing.JPanel banner_TicketMovieScreen;
    private javax.swing.JPanel banner_receipt;
    private javax.swing.JPanel banner_time;
    private javax.swing.JLabel ccvInfoLabel;
    private javax.swing.JLabel ccvLabel;
    private javax.swing.JLabel childPriceLabel;
    private javax.swing.JButton childTicketMinus_Button;
    private javax.swing.JButton childTicketPlus_Button;
    private javax.swing.JLabel childrenLabel;
    private javax.swing.JLabel columnALabel;
    private javax.swing.JLabel columnBLabel;
    private javax.swing.JLabel columnCLabel;
    private javax.swing.JLabel columnDLabel;
    private javax.swing.JLabel creditNumLabel;
    public javax.swing.JButton drStrangeButton;
    private javax.swing.JLabel expDateLabel;
    private javax.swing.JLabel expMonthLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JLabel moviePoster_receipt;
    private javax.swing.JLabel movieSelectedLabel;
    private javax.swing.JLabel nameOnCardLabel;
    private javax.swing.JLabel pleaseSelectLabel;
    private javax.swing.JPanel posterBorder;
    private javax.swing.JButton printButton;
    private javax.swing.JButton receiptToFirstScreenButton;
    private javax.swing.JLabel row1Label;
    private javax.swing.JLabel row2Label;
    private javax.swing.JLabel row3Label;
    private javax.swing.JLabel row4Label;
    private javax.swing.JLabel row5Label;
    private javax.swing.JLabel row6Label;
    private javax.swing.JToggleButton seatA1;
    private javax.swing.JToggleButton seatA2;
    private javax.swing.JToggleButton seatA3;
    private javax.swing.JToggleButton seatA4;
    private javax.swing.JToggleButton seatA5;
    private javax.swing.JToggleButton seatA6;
    private javax.swing.JToggleButton seatB1;
    private javax.swing.JToggleButton seatB2;
    private javax.swing.JToggleButton seatB3;
    private javax.swing.JToggleButton seatB4;
    private javax.swing.JToggleButton seatB5;
    private javax.swing.JToggleButton seatB6;
    private javax.swing.JToggleButton seatC1;
    private javax.swing.JToggleButton seatC2;
    private javax.swing.JToggleButton seatC3;
    private javax.swing.JToggleButton seatC4;
    private javax.swing.JToggleButton seatC5;
    private javax.swing.JToggleButton seatC6;
    private javax.swing.JToggleButton seatD1;
    private javax.swing.JToggleButton seatD2;
    private javax.swing.JToggleButton seatD3;
    private javax.swing.JToggleButton seatD4;
    private javax.swing.JToggleButton seatD5;
    private javax.swing.JToggleButton seatD6;
    private javax.swing.JTextField textField_credit;
    private javax.swing.JTextField textField_digits;
    private javax.swing.JTextField textField_name;
    private javax.swing.JLabel ticketCountLabel;
    private javax.swing.JLabel timeSlotPoster;
    private javax.swing.JToggleButton time_100pm;
    private javax.swing.JToggleButton time_1130am;
    private javax.swing.JToggleButton time_300pm;
    private javax.swing.JToggleButton time_400pm;
    private javax.swing.JToggleButton time_700pm;
    private javax.swing.JToggleButton time_930am;
    private javax.swing.JPanel timeslot_background;
    private javax.swing.JLabel totalSeatNumberLabel;
    public javax.swing.JLabel totalTicketsLabel;
    public javax.swing.JLabel totalTicketsLabel_seating;
    // End of variables declaration//GEN-END:variables

}
